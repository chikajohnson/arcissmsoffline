<div class="container row">
  <div class="col-md-6">
    <h2 class="lead"><strong> Examination Results Via SMS</strong></h2>
    <p>
      Students cannow check the results of their examination result from the comfort of their mobile phones.
      No need to visit the Centre to check one's results. The ARCIS SMS Result-checker allows
      students to request for the grade of a particular course or all the courses in a semester.
      <br>
      Students can change their passwword and seek help effortlessly by SMS.
    </p>
  </div>
  
  <div class="col-md-6">
    <h2 class="lead"><strong>Services Supported</strong></h2>
    <p>
      The SMS Result Checking System provides a range of servies relation to examination results. Some of these services include
      <ul>
        <li>Alert students when results are released</li>
        <li>Check results</li>
        <li>Change password</li>
        <li>Request help on correct message format</li>
        <li>Views a summary of exam results</li>
        <li>Backup results etc.</li>
      </ul>
    </div>
  </div>
  </div> <!-- /container -->
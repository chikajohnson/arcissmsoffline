<div>
	<div class="row text-center">
		<h4 class=""> <strong>Welcome to ARCIS SMS RESULT CHECKING SYSTEM </strong> ---- Lecturer Dashboard</h4>
		<hr>
	</div>
	
	<div>
		<div>
			<div class="row text-center">
				<div class="row">
					<div class="col-md-12 text-center">
						<h5>
							The <b> Lecturer Dashbaord</b> allows the course lecturers to upload the results of their courses in Excel format. 
						</h5>
						
						<hr>
					</div>

					<div>
						<div>
							<div class="col-sm-4">
								<p class="text-center">
									<a  class="btn btn-lg btn-primary " style="height:50%" title="click to enter the student's dashboard." href="<?php echo base_url(); ?>lecturer/results/add"><span class="glyphicon glyphicon-cog"></span>
									<strong><span class="text-default">Add a single Result</span></strong>
								</a>
							</p>
						</div>
						<div>
							<div class="col-sm-4">
								<p class="text-center">
									<a  class="btn btn-lg bg-default " style="height:50%" title="click to enter the student's dashboard." href="<?php echo base_url(); ?>lecturer/results/upload_result"><span class="glyphicon glyphicon-cog"></span>
									<strong><span class="text-default">Upload Results in Batch</span></strong>
								</a>
							</p>
						</div>
						<div class="col-sm-4">
							<p class="text-center">
								<a  class="btn btn-lg btn-default " style="height:50%" title="click to enter the student's dashboard." href="<?php echo base_url(); ?>lecturer/results"><span class="glyphicon glyphicon-book"></span>
								<strong><span class="text-default">View Uploaded Results</span></strong>
							</a>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>

<div class="row text-warning" style="padding: 15%; text-align:center;">
	<h1 style="font: 3em bold;" class="col-sm-offset-1 text-warning">Ooops.....Error 404! <br>The resource does not exist! </h1>
	<br>
	<br>
	<br>
	<h2><a href="<?php echo base_url(); ?><?php echo $this->uri->segment(1); ?>">Back</a></h2>
</div>
<div class="row" style="padding: 15%; text-align:center;">
	<h1 style="font: 3em bold;" class="col-sm-offset-1 text-warning">Ooops.....Error 404! <br>The resource does not exist! </h1>
</div>
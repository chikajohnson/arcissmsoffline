<div class="col-sm-12 row text-center">
	<h2> Resource does not exist! </h2>
</div>


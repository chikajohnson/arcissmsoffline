<h2 class="page-header">Dashboard</h2>
<h4>Latest Activities</h4>
<ul class="list-group">
	<li class="list-group-item">Some Events to happen</li>
</ul>